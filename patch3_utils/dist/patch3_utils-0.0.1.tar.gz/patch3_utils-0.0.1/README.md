# PATCH3 Utilities

This is a package containing utilities written primarily for the Pipeline for Analysis of Tomographic Clustering with HSC DR3 (`PATCH3`), but with possible applications elsewhere.